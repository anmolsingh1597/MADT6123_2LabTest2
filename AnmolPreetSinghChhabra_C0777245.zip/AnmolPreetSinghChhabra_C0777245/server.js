// var express = require('express');
// var app = express();
// app.use(express.static('img'));
// app.use(express.static('htmldir'));
// app.use(express.static('public'))
// var html_dir = 'C:/simplewebpage/html/';
// app.get('/', function (req, res) {
//    
//     res.sendFile('index.html' , { root : __dirname});
// //     res.sendFile(html_dir + 'file1.html');

// })

// var server = app.listen(8089, function () {
//    var host = server.address().address
//    var port = server.address().port
//    
//    console.log("Example app listening at http://%s:%s", host, port)
// })

var express = require('express');
var app = express();
//app.use(express.static('imgages'));
app.use(express.static('public'));


//app.use('/static', express.static(path.join(__dirname, 'public')));

app.get('/', function (req, res) {
    res.sendFile('index.html' , { root : __dirname});

})

var server = app.listen(8081, function () {
   var host = server.address().address
   var port = server.address().port
   
   console.log("Example app listening at http://%s:%s", host, port)
})